"use strict";

const dgram = require("dgram");
const dnsPacket = require("dns-packet");

const TARGET_IP = "127.0.0.1";
const PORT = 5353;
const HOSTS = new Set([
  "growtopia1.com",
  "www.growtopia1.com",
  "growtopia2.com",
  "www.growtopia2.com"
]);

const server = dgram.createSocket("udp4");

server.on("error", (err) => {
  console.error("DNS server error:", err);
  process.exit(1);
});

server.on("message", (msg, rinfo) => {
  try {
    const query = dnsPacket.decode(msg);
    const question = query.questions?.[0];
    if (!question) {
      sendError(rinfo);
      return;
    }

    const { name, type } = question;
    const lower = name.toLowerCase();

    if (HOSTS.has(lower) && (type === dnsPacket.TYPE.A || type === dnsPacket.TYPE.ANY)) {
      const reply = dnsPacket.encode({
        type: "response",
        id: query.id,
        flags: dnsPacket.Flags.RESPONSECODE_NOERR,
        questions: [question],
        answers: [{
          name,
          type: dnsPacket.TYPE.A,
          class: dnsPacket.CLASS.IN,
          ttl: 300,
          data: TARGET_IP
        }]
      });
      server.send(reply, rinfo.port, rinfo.address);
      console.log(`[DNS] ${name} -> ${TARGET_IP}`);
    } else {
      // Forward to real DNS (1.1.1.1) – simplified: just send NXDOMAIN for now
      sendError(rinfo);
    }
  } catch (err) {
    console.error("DNS parse error:", err.message);
    sendError(rinfo);
  }
});

function sendError(rinfo) {
  try {
    const errPacket = dnsPacket.encode({
      type: "response",
      flags: dnsPacket.Flags.RESPONSECODE_NXDOMAIN
    });
    server.send(errPacket, rinfo.port, rinfo.address);
  } catch (_) {}
}

server.bind(PORT, () => {
  console.log(`[DNS] Listening on UDP ${PORT} — resolve growtopia1.com/growtopia2.com -> ${TARGET_IP}`);
});
